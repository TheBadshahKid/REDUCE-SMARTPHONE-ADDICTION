import React, { useState } from 'react';
import { Clock, Phone, Brain, Heart, Battery, Moon, Sun, Trophy, Target, Award, Star, Zap, Calendar, CheckCircle, BarChart } from 'lucide-react';

function App() {
  const [screenTime, setScreenTime] = useState(0);
  const [selectedChallenge, setSelectedChallenge] = useState(0);

  const tips = [
    { icon: <Clock size={24} />, text: "Set specific phone-free times during the day" },
    { icon: <Moon size={24} />, text: "Keep phones out of the bedroom at night" },
    { icon: <Brain size={24} />, text: "Practice mindful phone usage" },
    { icon: <Heart size={24} />, text: "Replace scrolling with real-world connections" }
  ];

  const challenges = [
    { icon: <Target size={24} />, title: "2-Hour Challenge", description: "Limit screen time to 2 hours today" },
    { icon: <Calendar size={24} />, title: "Phone-Free Morning", description: "No phone for the first hour after waking" },
    { icon: <Zap size={24} />, title: "Focus Mode", description: "Use focus mode for 3 hours today" }
  ];

  const achievements = [
    { icon: <Award size={24} />, title: "Early Bird", progress: 80 },
    { icon: <Star size={24} />, title: "Digital Minimalist", progress: 65 },
    { icon: <Trophy size={24} />, title: "Streak Master", progress: 90 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Phone className="text-purple-600" />
            <span className="text-xl font-bold text-gray-800">Digital Balance</span>
          </div>
          <div className="flex space-x-4">
            <a href="#challenges" className="text-gray-600 hover:text-purple-600">Challenges</a>
            <a href="#tips" className="text-gray-600 hover:text-purple-600">Tips</a>
            <a href="#tracker" className="text-gray-600 hover:text-purple-600">Tracker</a>
            <a href="#achievements" className="text-gray-600 hover:text-purple-600">Achievements</a>
          </div>
        </div>
      </nav>

      <main>
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Take Control of Your Digital Life
            </h1>
            <p className="text-xl text-gray-600 mb-12">
              Your journey to a healthier relationship with technology starts here
            </p>
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-12">
              <div className="flex flex-col items-center">
                <Battery className="w-16 h-16 text-purple-600 mb-4" />
                <h2 className="text-2xl font-semibold mb-2">Daily Digital Wellness Score</h2>
                <div className="w-full max-w-xs bg-gray-200 rounded-full h-4 mb-4">
                  <div 
                    className="bg-purple-600 h-4 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min((8 - screenTime) * 12.5, 100)}%` }}
                  ></div>
                </div>
                <div className="flex items-center space-x-4">
                  <button 
                    onClick={() => setScreenTime(Math.max(0, screenTime - 1))}
                    className="bg-purple-100 text-purple-600 p-2 rounded-full hover:bg-purple-200 transition-colors"
                  >
                    <Sun size={20} />
                  </button>
                  <span className="text-2xl font-bold text-gray-800">{screenTime}h</span>
                  <button 
                    onClick={() => setScreenTime(Math.min(24, screenTime + 1))}
                    className="bg-purple-100 text-purple-600 p-2 rounded-full hover:bg-purple-200 transition-colors"
                  >
                    <Moon size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="challenges" className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Daily Challenges</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {challenges.map((challenge, index) => (
                <div 
                  key={index}
                  onClick={() => setSelectedChallenge(index)}
                  className={`bg-gray-50 rounded-xl p-6 cursor-pointer transition-all ${
                    selectedChallenge === index ? 'ring-2 ring-purple-500 shadow-lg' : 'hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="text-purple-600">{challenge.icon}</div>
                    <h3 className="font-semibold text-lg">{challenge.title}</h3>
                  </div>
                  <p className="text-gray-600">{challenge.description}</p>
                  {selectedChallenge === index && (
                    <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                      Start Challenge
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="tips" className="py-16 bg-gradient-to-r from-purple-50 to-blue-50">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Smart Habits for Digital Wellness</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {tips.map((tip, index) => (
                <div key={index} className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                  <div className="text-purple-600 mb-4">{tip.icon}</div>
                  <p className="text-gray-700">{tip.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="achievements" className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Your Achievements</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-6">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="text-yellow-500">{achievement.icon}</div>
                    <h3 className="font-semibold text-lg">{achievement.title}</h3>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-yellow-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${achievement.progress}%` }}
                    ></div>
                  </div>
                  <p className="text-right mt-2 text-sm text-gray-600">{achievement.progress}%</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="tracker" className="py-16 bg-gradient-to-r from-purple-50 to-blue-50">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Weekly Progress</h2>
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex justify-between items-end space-x-4 mb-8 h-48">
                {[...Array(7)].map((_, i) => (
                  <div key={i} className="flex flex-col items-center flex-1">
                    <div 
                      className="w-full bg-purple-200 rounded-t-lg transition-all duration-500" 
                      style={{
                        height: `${Math.random() * 100}%`,
                        backgroundColor: i === 6 ? 'rgb(147, 51, 234)' : undefined
                      }}
                    ></div>
                    <span className="text-sm text-gray-500 mt-2">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                    </span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-center space-x-4">
                <Trophy className="text-yellow-500" />
                <span className="text-lg font-semibold">Current Streak: 5 days</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Digital Balance</h3>
              <p className="text-gray-400">Helping teens build healthy digital habits</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Research</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;